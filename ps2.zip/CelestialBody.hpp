#pragma once

#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>

using DATA_TYPE = double;


class CelestialBody{
    public:
        CelestialBody();
        virtual void draw();
    private:
    DATA_TYPE xPos;
    DATA_TYPE yPos;
    DATA_TYPE xVel;
    DATA_TYPE yVel;
    DATA_TYPE mass;

};

class Universe{
    public:
    Universe(const char* filename);

    CelestialBody initBody(const char* fileName);

    private:
    int numBodies;
    std::vector <CelestialBody> system;

};

