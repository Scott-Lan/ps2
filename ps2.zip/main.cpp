#include "CelestialBody.hpp"
using DATA_TYPE = double;
int main(){

    Universe solarSystem(Planets);
    return 0;
}
