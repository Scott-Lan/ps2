#include "CelestialBody.hpp"
using DATA_TYPE = double;

Universe::Universe(const char* fileName){
    std::ifstream in;
    in.open(fileName);
    //if file is open
    if(in.is_open()){
        std::string line;
        getline(in, line);
        std::cout << "first line: " << line << std::endl;
        //get total number of bodies to create
        int num = stoi(line);
        //init bodies to class from file
        for(int i = 0; i < num; ++i){
            system.push_back(initBody(fileName));
        }
    }

}

CelestialBody Universe::initBody(const char* fileName){
    std::ifstream in;
    CelestialBody newBody;
    in.open(fileName);
    //if file is open for reading
    if(in.is_open())
    {
        //until end of file is reached
        while(!in.eof())
        {
            std::string temp;
            //skip first 2 lines;
            for(int i = 0; i < 2; ++i)
            {
                getline(in, temp);
            }
            // std::cout << "data line " << i << ": \n";

        }
        return newBody;   
    }
    std::cout << "file did not open; code 2\n"; return 2;
}

CelestialBody(DATA_TYPE xPos = 0, DATA_TYPE yPos = 0, DATA_TYPE xVel = 0,
                DATA_TYPE yVel = 0, DATA_TYPE mass = 0)
{

}